
#DESCRIPTION

this is a library managment app.
the app is connected to a sqlite database which hold's 3 tables:
 CUSTOMERS
 BOOKS 
 LOANS
 
 using the app you can add and remove customers and books from the database
 aswell you can manage loans the library gives out.
 

#RUNING THE APP

to run the app please first install a virtual enviroment and install the the needed
requirments using the requirments txt file using the command

$ pip install -r requirements.txt

once install you just need to run app.py using command:

windows: py app.py
bash: python3 app.py

the app will start on your localhost 

once you enter the app you can add some data using the dummy data button which will make 
testing it much easier.


#AUTHOR

YONI OREN



 
